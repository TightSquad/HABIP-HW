# Notes by CMS

Install steps:

Download latest GerbMerge here (current files are version 1.9): https://github.com/provideyourown/gerbmerge

1) Installed SimpleParse 2.1.1a2 from here: http://simpleparse.sourceforge.net
	Note: I saved the download zip in this top level directory as "SimpleParse-2.1.1a2.zip"
2) Then I ran the gerbmerge installer and it failed, so I edited to the setup.py as follows:
	Line 40: DestLib = distutils.sysconfig.get_python_lib() # CMS: modified from distutils.sysconfig.get_config_var('LIBPYTHON')
	Line 55:        version = "%d.%d" % (VERSION_MAJOR, int(str(VERSION_MINOR)[0])), # CMS: modified from (VERSION_MAJOR, VERSION_MINOR),
3) Installer still failed with the following error: "error: can't copy 'COPYING': doesn't exist or not a regular file"
	All you have to do is create a file called "COPYING" in the top level: touch COPYING
4) Installer finally installed. Here is the output:
	" ******** Installation Complete ******** 

Sample files and documentation have been installed in:
    /usr/local/Cellar/python/2.7.11/Frameworks/Python.framework/Versions/2.7/lib/python2.7/site-packages/gerbmerge

A shortcut to starting the program has been installed as:
    /usr/local/Cellar/python/2.7.11/Frameworks/Python.framework/Versions/2.7/bin/gerbmerge "

5) run gerbmerge with: python /usr/local/lib/python2.7/site-packages/gerbmerge/gerbmerge.py

	Documentation can be found under doc/index.html    <— It’s a must read!!!

APPENDIX) downloaded gerbv for a gerber viewer: brew install gerbv